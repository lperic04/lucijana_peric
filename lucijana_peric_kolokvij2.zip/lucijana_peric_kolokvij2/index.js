var unesiteVašeime = prompt ("Unesite Vaše ime")
 
    alert ("Vaše ime je" + unesiteVašeime );
    

